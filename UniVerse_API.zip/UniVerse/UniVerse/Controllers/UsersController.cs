﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Universe.Api.Data;
using Universe.Api.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Universe.Api.Controllers
{
    [ApiController]
    [Route("users")]
    public class UsersController : ControllerBase
    {
        private readonly AppDbContext _context;
        public UsersController(AppDbContext context) { _context = context; }

        [HttpGet]
        [Authorize]
        public IActionResult GetAll() => Ok(_context.Users.ToList());

        [HttpGet("{id}")]
        [Authorize]
        public IActionResult GetById(int id)
        {
            var user = _context.Users
                .Include(u => u.Courses)
                .Include(u => u.Notifications)
                .Include(u => u.SentMessages)
                .Include(u => u.ReceivedMessages)
                .FirstOrDefault(u => u.UserID == id);
            return user == null ? NotFound() : Ok(user);
        }


        [HttpGet("me")]
        [Authorize]
        public IActionResult GetCurrentUser()
        {
            // Extract the UserID from the JWT claims
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
                return Unauthorized(new { message = "Invalid token" });

            if (!int.TryParse(userIdClaim, out int userId))
                return Unauthorized(new { message = "Invalid token" });

            // Retrieve user with related data
            var user = _context.Users
                .Include(u => u.Courses)
                .Include(u => u.Notifications)
                .Include(u => u.SentMessages)
                .Include(u => u.ReceivedMessages)
                .FirstOrDefault(u => u.UserID == userId);

            if (user == null)
                return NotFound(new { message = "User not found" });

            // Return a simplified DTO
            var profile = new
            {
                user.UserID,
                user.Username,
                user.Email,
                user.Role,
                user.FirstName,
                user.LastName
            };

            return Ok(profile);
        }

        [HttpGet("students")]
        [Authorize]
        public IActionResult GetAllStudents()
        {
            var students = _context.Users
                .Where(u => u.Role == "Student")
                .Select(u => new
                {
                    u.UserID,
                    u.Username,
                    u.Email,
                    u.FirstName,
                    u.LastName,
                    u.Role
                })
                .ToList();

            return Ok(students);
        }


    }
}
