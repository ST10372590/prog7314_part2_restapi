﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Universe.Api.Data;
using Universe.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Universe.Api.Controllers
{
    [ApiController]
    [Route("assessments")]
    public class AssessmentsController : ControllerBase
    {
        private readonly AppDbContext _context;
        public AssessmentsController(AppDbContext context) { _context = context; }

        [HttpGet]
        [Authorize]
        public IActionResult GetAll() => Ok(_context.Assessments.Include(a => a.Course).Include(a => a.Submissions).ToList());

        [HttpGet("{id}")]
        [Authorize]
        public IActionResult GetById(int id)
        {
            var assessment = _context.Assessments.Include(a => a.Course).Include(a => a.Submissions).FirstOrDefault(a => a.AssessmentID == id);
            return assessment == null ? NotFound() : Ok(assessment);
        }

        [HttpPost("create")]
        [Authorize(Roles = "Lecturer")]
        public IActionResult Create([FromBody] Assessment assessment)
        {
            _context.Assessments.Add(assessment);
            _context.SaveChanges();
            return Ok(new { message = "Assessment created" });
        }
    }
}
