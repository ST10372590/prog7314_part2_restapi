﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Universe.Api.Data;
using Universe.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Universe.Api.Controllers
{
    [ApiController]
    [Route("submissions")]
    public class SubmissionsController : ControllerBase
    {
        private readonly AppDbContext _context;
        public SubmissionsController(AppDbContext context) { _context = context; }

        [HttpGet]
        [Authorize]
        public IActionResult GetAll() => Ok(_context.Submissions.Include(s => s.Student).Include(s => s.Assessment).ToList());

        [HttpPost("submit")]
        [Authorize]
        public IActionResult Submit([FromBody] Submission submission)
        {
            _context.Submissions.Add(submission);
            _context.SaveChanges();
            return Ok(new { message = "Submission recorded" });
        }
    }
}
