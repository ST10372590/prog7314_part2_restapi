﻿using System;
using Microsoft.EntityFrameworkCore;
using Universe.Api.Models;

namespace Universe.Api.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // === Existing DbSets ===
        public DbSet<User> Users { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Module> Modules { get; set; }
        public DbSet<Schedule> Schedules { get; set; }
        public DbSet<Announcement> Announcements { get; set; }
        public DbSet<Progress> ProgressRecords { get; set; }
        public DbSet<ClassFile> Files { get; set; }
        public DbSet<CalendarEvent> CalendarEvents { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<Message> Messages { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<GroupMember> GroupMembers { get; set; }
        public DbSet<GroupMessage> GroupMessages { get; set; }
        public DbSet<Assessment> Assessments { get; set; }
        public DbSet<Submission> Submissions { get; set; }
        public DbSet<UserCourse> UserCourses { get; set; }
        public DbSet<UserSettings> UserSetting { get; set; }
        public DbSet<UserStats> UserStats { get; set; }

        // === NEW Gamification DbSets ===
        public DbSet<Badge> Badges { get; set; }
        public DbSet<UserBadge> UserBadges { get; set; }
        public DbSet<Reward> Rewards { get; set; }
        public DbSet<UserReward> UserRewards { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // === Primary Keys ===
            modelBuilder.Entity<User>().HasKey(u => u.UserID);
            modelBuilder.Entity<Course>().HasKey(c => c.CourseID);
            modelBuilder.Entity<Module>().HasKey(m => m.ModuleID);
            modelBuilder.Entity<Notification>().HasKey(n => n.NotificationID);
            modelBuilder.Entity<Message>().HasKey(m => m.MessageID);
            modelBuilder.Entity<CalendarEvent>().HasKey(c => c.EventID);
            modelBuilder.Entity<ClassFile>().HasKey(f => f.FileID);
            modelBuilder.Entity<Assessment>().HasKey(a => a.AssessmentID);
            modelBuilder.Entity<Submission>().HasKey(s => s.SubmissionID);
            modelBuilder.Entity<Schedule>().HasKey(s => s.Id);
            modelBuilder.Entity<Announcement>().HasKey(a => a.Id);
            modelBuilder.Entity<Progress>().HasKey(p => p.Id);
            modelBuilder.Entity<UserSettings>().HasKey(u => u.UserID);

            // === Relationships (Existing) ===
            modelBuilder.Entity<Course>()
                .HasOne(c => c.Lecturer)
                .WithMany(u => u.Courses)
                .HasForeignKey(c => c.LecturerID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Module>()
                .HasOne(m => m.Course)
                .WithMany(c => c.Modules)
                .HasForeignKey(m => m.CourseID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Assessment>()
                .HasOne(a => a.Course)
                .WithMany(c => c.Assessments)
                .HasForeignKey(a => a.CourseID);

            modelBuilder.Entity<Submission>()
                .HasOne(s => s.Assessment)
                .WithMany(a => a.Submissions)
                .HasForeignKey(s => s.AssessmentID);

            modelBuilder.Entity<Submission>()
                .HasOne(s => s.Student)
                .WithMany()
                .HasForeignKey(s => s.UserID);

            modelBuilder.Entity<Message>()
                .HasOne(m => m.Sender)
                .WithMany(u => u.SentMessages)
                .HasForeignKey(m => m.SenderID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Message>()
                .HasOne(m => m.Receiver)
                .WithMany(u => u.ReceivedMessages)
                .HasForeignKey(m => m.ReceiverID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Notification>()
                .HasOne(n => n.User)
                .WithMany(u => u.Notifications)
                .HasForeignKey(n => n.UserID);

            modelBuilder.Entity<UserSettings>()
                .HasOne(us => us.User)
                .WithOne(u => u.Settings)
                .HasForeignKey<UserSettings>(us => us.UserID)
                .OnDelete(DeleteBehavior.Cascade);

            // === NEW Relationships: Gamification ===

            // Each UserBadge links a User ↔ Badge (many-to-many)
            // --- UserStats → User ---
            modelBuilder.Entity<UserStats>()
                .HasOne(us => us.User)
                .WithOne() // If your User class doesn’t have a UserStats property
                .HasForeignKey<UserStats>(us => us.UserID)
                .OnDelete(DeleteBehavior.Cascade);

            // --- UserStats → UserBadge (1-to-many) ---
            modelBuilder.Entity<UserBadge>()
                .HasOne(ub => ub.UserStats)
                .WithMany(us => us.UserBadges)
                .HasForeignKey(ub => ub.UserStatsId)
                .OnDelete(DeleteBehavior.Cascade);

            // --- Badge → UserBadge (1-to-many) ---
            modelBuilder.Entity<UserBadge>()
                .HasOne(ub => ub.Badge)
                .WithMany(b => b.UserBadges)
                .HasForeignKey(ub => ub.BadgeId)
                .OnDelete(DeleteBehavior.Cascade);

            // --- UserStats → UserReward (1-to-many) ---
            modelBuilder.Entity<UserReward>()
                .HasOne(ur => ur.UserStats)
                .WithMany(us => us.UserRewards)
                .HasForeignKey(ur => ur.UserStatsId)
                .OnDelete(DeleteBehavior.Cascade);

            // --- Reward → UserReward (1-to-many) ---
            modelBuilder.Entity<UserReward>()
                .HasOne(ur => ur.Reward)
                .WithMany(r => r.UserRewards)
                .HasForeignKey(ur => ur.RewardId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }

    public static class SeedData
    {
        public static void Initialize(AppDbContext context)
        {
            context.Database.EnsureCreated();
        }
    }
}
